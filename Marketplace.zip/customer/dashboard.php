<?php
include_once("./../config/config.php");
include("includes/header.php");
?>
    <div id="homepage-1">
        Dashboard
    </div>
<?php include("includes/footer.php");?>