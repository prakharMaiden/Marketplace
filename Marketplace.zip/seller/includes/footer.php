<footer class="main-footer">
    <strong>Copyright &copy; <?php echo date("Y");?> <a href="#">Krishna Gold Industries</a>.</strong> All rights
    reserved.
</footer>
</div>
<script src="<?php echo PUBLIC_PATH;?>/css/plugins/jquery/jquery.min.js"></script>
<script src="<?php echo PUBLIC_PATH;?>/css/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo PUBLIC_PATH;?>/css/plugins/jquery-validation/jquery.validate.min.js"></script>
<script src="<?php echo PUBLIC_PATH;?>/css/plugins/jquery-validation/additional-methods.min.js"></script>
<script src="<?php echo PUBLIC_PATH;?>/js/adminlte.min.js"></script>
<script src="<?php echo PUBLIC_PATH;?>/js/demo.js"></script>
<script src="<?php echo PUBLIC_PATH; ?>/css/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo PUBLIC_PATH; ?>/css/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo PUBLIC_PATH; ?>/css/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo PUBLIC_PATH; ?>/css/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>

</body>
</html>
